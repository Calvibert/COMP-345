/*
 * query_result.h
 *
 *  Created on: Nov 5, 2017
 *      Author: Maude
 */

#ifndef QUERY_RESULT_H_
#define QUERY_RESULT_H_

class query_result {
public:
	query_result();
	virtual ~query_result();
};

#endif /* QUERY_RESULT_H_ */
