/*
 * query_result.cpp
 *
 *  Created on: Nov 5, 2017
 *      Author: Maude
 */

#include "query_result.h"

query_result::query_result() {
	// TODO Auto-generated constructor stub

}

query_result::~query_result() {
	// TODO Auto-generated destructor stub
}

