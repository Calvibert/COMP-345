/*
 * indexer.cpp
 *
 *  Created on: Nov 5, 2017
 *      Author: Maude
 */

#include "indexer.h"
